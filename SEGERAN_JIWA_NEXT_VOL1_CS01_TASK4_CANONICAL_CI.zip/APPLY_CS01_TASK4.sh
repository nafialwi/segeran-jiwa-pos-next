#!/usr/bin/env bash
set -euo pipefail

ROOT=$(git rev-parse --show-toplevel)
cd "$ROOT"
BRANCH=$(git branch --show-current)

if [[ "$BRANCH" != "work/cs-01" ]]; then
  echo "ERROR: Task 4 must run on work/cs-01; current=$BRANCH" >&2
  exit 1
fi
if [[ -n "$(git status --porcelain)" ]]; then
  echo "ERROR: working tree must be clean before Task 4" >&2
  git status --short >&2
  exit 1
fi
for required in tools/mobile_inbox/contract.py tools/mobile_inbox/intake.py tools/mobile_inbox/package_manifest.schema.json tests/test_mobile_inbox.py scripts/verify.mjs; do
  if [[ ! -f "$required" ]]; then
    echo "ERROR: Task 3 artifact missing: $required" >&2
    exit 1
  fi
done

npm run verify
echo "TASK4_PREFLIGHT=PASS"

python3 - <<'PY'
from pathlib import Path
p = Path('tests/repo-guard.test.mjs')
s = p.read_text(encoding='utf-8')
marker = "describe('canonical CI contract'"
if marker in s:
    raise SystemExit('ERROR: Task 4 CI contract test already present before RED')
s += r'''

describe('canonical CI contract', () => {
  it('uses push CI for main/work branches and publishes canonical-verify', () => {
    const workflow = readFileSync(
      new URL('../.github/workflows/ci.yml', import.meta.url),
      'utf8',
    );

    expect(workflow).toContain("'work/**'");
    expect(workflow).toContain('npm run verify');
    expect(workflow).toContain('canonical-verify');
    expect(workflow).toContain('statuses: write');
    expect(workflow).not.toMatch(/^\s*pull_request\s*:/m);
  });
});
'''
p.write_text(s, encoding='utf-8')
PY

set +e
npm run test:js -- tests/repo-guard.test.mjs >/tmp/cs01-task4-red.log 2>&1
RED=$?
set -e
if [[ "$RED" -eq 0 ]]; then
  echo "ERROR: Task 4 TDD RED did not occur" >&2
  cat /tmp/cs01-task4-red.log >&2
  exit 1
fi
if ! grep -Eq 'ci\.yml|ENOENT|no such file|canonical CI contract' /tmp/cs01-task4-red.log; then
  echo "ERROR: Task 4 RED failed for an unexpected reason" >&2
  cat /tmp/cs01-task4-red.log >&2
  exit 1
fi
echo "TASK4_TDD_RED=CONFIRMED"

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
mkdir -p .github/workflows
cp "$SCRIPT_DIR/payload/.github/workflows/ci.yml" .github/workflows/ci.yml
cp "$SCRIPT_DIR/payload/.github/pull_request_template.md" .github/pull_request_template.md

npx prettier --write tests/repo-guard.test.mjs .github/workflows/ci.yml .github/pull_request_template.md
npm run verify
git diff --check
echo "TASK4_LOCAL_VERIFY=PASS"

git add .github/workflows/ci.yml .github/pull_request_template.md tests/repo-guard.test.mjs
git diff --cached --check
if git diff --cached --quiet; then
  echo "ERROR: Task 4 produced no staged change" >&2
  exit 1
fi

git commit -m "ci(cs-01): establish canonical verification status"
git push -u origin work/cs-01
HEAD_SHA=$(git rev-parse HEAD)

echo "TASK4_PUSHED_COMMIT=$HEAD_SHA"

if ! command -v gh >/dev/null 2>&1; then
  echo "ERROR: gh CLI is required to verify the GitHub Actions acceptance gate" >&2
  exit 1
fi
REPO=$(gh repo view --json nameWithOwner -q .nameWithOwner)
if [[ -z "$REPO" ]]; then
  echo "ERROR: unable to resolve GitHub repository" >&2
  exit 1
fi

RUN_ID=""
RUN_URL=""
for _ in $(seq 1 60); do
  ROW=$(gh api "repos/$REPO/actions/workflows/ci.yml/runs?branch=work%2Fcs-01&per_page=20" \
    --jq ".workflow_runs[] | select(.head_sha == \"$HEAD_SHA\") | [.id,.html_url] | @tsv" 2>/dev/null | head -n1 || true)
  if [[ -n "$ROW" ]]; then
    RUN_ID=${ROW%%$'\t'*}
    RUN_URL=${ROW#*$'\t'}
    break
  fi
  sleep 5
done
if [[ -z "$RUN_ID" ]]; then
  echo "ERROR: canonical-ci run not found for $HEAD_SHA" >&2
  gh run list --workflow ci.yml --branch work/cs-01 --limit 10 || true
  exit 1
fi

echo "TASK4_CI_RUN_ID=$RUN_ID"
echo "TASK4_CI_URL=$RUN_URL"
if ! gh run watch "$RUN_ID" --exit-status; then
  echo "ERROR: canonical-ci failed" >&2
  gh run view "$RUN_ID" --log-failed || true
  exit 1
fi
echo "TASK4_CI_RUN=PASS"

STATUS=""
for _ in $(seq 1 24); do
  STATUS=$(gh api "repos/$REPO/commits/$HEAD_SHA/status" \
    --jq '[.statuses[] | select(.context == "canonical-verify")][0].state // ""' 2>/dev/null || true)
  if [[ "$STATUS" == "success" ]]; then
    break
  fi
  if [[ "$STATUS" == "failure" || "$STATUS" == "error" ]]; then
    echo "ERROR: canonical-verify status=$STATUS" >&2
    exit 1
  fi
  sleep 5
done
if [[ "$STATUS" != "success" ]]; then
  echo "ERROR: canonical-verify success status not observed; state=${STATUS:-missing}" >&2
  gh api "repos/$REPO/commits/$HEAD_SHA/status" --jq '.statuses[] | [.context,.state,.description] | @tsv' || true
  exit 1
fi

echo "TASK4_CANONICAL_STATUS=success"
if [[ -n "$(git status --porcelain)" ]]; then
  echo "ERROR: working tree is not clean after Task 4" >&2
  git status --short >&2
  exit 1
fi

echo "TASK4_RESULT=PASS"
echo "BRANCH=$(git branch --show-current)"
echo "COMMIT=$HEAD_SHA"
echo "WORKTREE_CLEAN=yes"

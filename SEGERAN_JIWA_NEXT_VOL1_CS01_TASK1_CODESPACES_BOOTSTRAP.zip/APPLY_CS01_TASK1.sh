#!/usr/bin/env bash
set -euo pipefail

REPO_URL="https://github.com/nafialwi/segeran-jiwa-pos-next.git"
BRANCH="work/cs-01"
PACKAGE_ZIP="SEGERAN_JIWA_NEXT_VOL1_CS01_TASK1_CODESPACES_BOOTSTRAP.zip"

echo "== Segeran Jiwa Next Vol. 1 | CS-01 Task 1 bootstrap =="

if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "ERROR: Jalankan dari root Codespace repository segeran-jiwa-pos-next." >&2
  exit 2
fi

current_remote="$(git remote get-url origin 2>/dev/null || true)"
if [[ -z "$current_remote" ]]; then
  git remote add origin "$REPO_URL"
elif [[ "$current_remote" != "$REPO_URL" ]]; then
  git remote set-url origin "$REPO_URL"
fi

# Always leave main as the initialization anchor only.
git fetch origin main || true
if git show-ref --verify --quiet "refs/heads/$BRANCH"; then
  git switch "$BRANCH"
elif git ls-remote --exit-code --heads origin "$BRANCH" >/dev/null 2>&1; then
  git switch -c "$BRANCH" --track "origin/$BRANCH"
else
  git switch -c "$BRANCH"
fi

# Node 24 is mandatory for CS-01. Use nvm when Codespaces shell is not already on 24.
node_major="$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
if [[ "$node_major" != "24" ]]; then
  if command -v nvm >/dev/null 2>&1; then
    nvm install 24
    nvm use 24
  elif [[ -s "${NVM_DIR:-$HOME/.nvm}/nvm.sh" ]]; then
    # shellcheck disable=SC1090
    source "${NVM_DIR:-$HOME/.nvm}/nvm.sh"
    nvm install 24
    nvm use 24
  else
    echo "ERROR: Node 24 belum aktif dan nvm tidak ditemukan." >&2
    exit 3
  fi
fi

echo "Node: $(node -v)"
echo "npm : $(npm -v)"

# Resolve and lock exact dependency graph in the real Node 24 environment.
npm install react react-dom
npm install -D typescript vite @vitejs/plugin-react vitest @types/react @types/react-dom @types/node eslint @eslint/js typescript-eslint globals prettier

# Task 1 acceptance gates.
npm run format:check
npm run lint
npm run typecheck
npm run test:js
npm run build
git diff --check

# Bootstrap artifacts are transport-only and must not be committed.
rm -f "$PACKAGE_ZIP" "APPLY_CS01_TASK1.sh"

# Commit only after all acceptance gates passed.
git add .
if git diff --cached --quiet; then
  echo "Tidak ada perubahan baru untuk di-commit."
else
  git commit -m "chore(cs-01): bootstrap POS Next repository"
fi

git push -u origin "$BRANCH"

echo
echo "TASK1_RESULT=PASS"
echo "BRANCH=$(git branch --show-current)"
echo "COMMIT=$(git rev-parse HEAD)"
echo "REMOTE=$(git remote get-url origin)"

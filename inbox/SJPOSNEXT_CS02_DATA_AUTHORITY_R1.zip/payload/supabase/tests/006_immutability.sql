begin;

do $$
declare
  v_business uuid; v_cash uuid; v_move uuid; v_update_blocked boolean := false; v_delete_blocked boolean := false;
begin
  select id into v_business from public.businesses where code='SJ';
  select id into v_cash from public.money_accounts where business_id=v_business and code='KAS_UTAMA';
  v_move := private.record_money_movement(v_business,null,'itest-immutability','OPENING_BALANCE',null,v_cash,12345,'TEST','IMMUTABLE-1','CS02_TEST',null);
  begin update public.money_movements set amount=999 where id=v_move; exception when object_not_in_prerequisite_state then v_update_blocked := true; end;
  begin delete from public.money_movements where id=v_move; exception when object_not_in_prerequisite_state then v_delete_blocked := true; end;
  if not v_update_blocked or not v_delete_blocked then raise exception 'IMMUTABILITY_NOT_ENFORCED'; end if;
end $$;

select 'IMMUTABILITY_INTEGRATION_PASS' as status;
rollback;

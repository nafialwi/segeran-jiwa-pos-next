begin;

do $$
begin
  if not exists (select 1 from private.schema_versions where version=1 and milestone='CS-02' and blueprint_baseline='1.0') then
    raise exception 'CS02_SCHEMA_VERSION_MISSING';
  end if;
  if (select count(*) from public.businesses where code='SJ') <> 1 then raise exception 'CS02_BUSINESS_SEED_INVALID'; end if;
  if (select count(*) from public.locations l join public.businesses b on b.id=l.business_id where b.code='SJ' and l.code in ('GUDANG','GERAI')) <> 2 then raise exception 'CS02_LOCATION_SEED_INVALID'; end if;
  if (select count(*) from public.money_accounts a join public.businesses b on b.id=a.business_id where b.code='SJ' and a.code in ('KAS_UTAMA','BANK','QRIS_BELUM_CAIR','QRIS_SUDAH_CAIR')) <> 4 then raise exception 'CS02_MONEY_ACCOUNT_SEED_INVALID'; end if;
end $$;

select 'FOUNDATION_ASSERTIONS_PASS' as status;
rollback;

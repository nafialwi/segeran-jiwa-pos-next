begin;

do $$
declare
  v_business uuid; v_cash uuid; v_bank uuid; v_transfer uuid; v_retry uuid; v_cash_bal numeric; v_bank_bal numeric;
begin
  select id into v_business from public.businesses where code='SJ';
  select id into v_cash from public.money_accounts where business_id=v_business and code='KAS_UTAMA';
  select id into v_bank from public.money_accounts where business_id=v_business and code='BANK';
  perform private.record_money_movement(v_business,null,'itest-money-open','OPENING_BALANCE',null,v_cash,100000,'TEST','MONEY-OPEN','CS02_TEST',null);
  v_transfer := private.record_money_movement(v_business,null,'itest-money-transfer','TRANSFER',v_cash,v_bank,25000,'TEST','MONEY-XFER','CS02_TEST',null);
  v_retry := private.record_money_movement(v_business,null,'itest-money-transfer','TRANSFER',v_cash,v_bank,25000,'TEST','MONEY-XFER','CS02_TEST',null);
  if v_retry <> v_transfer then raise exception 'MONEY_REPLAY_ID_MISMATCH'; end if;
  perform private.record_money_movement(v_business,null,'itest-money-expense','EXPENSE',v_cash,null,10000,'TEST','MONEY-EXP','CS02_TEST',null);
  select balance into v_cash_bal from public.money_balances where business_id=v_business and account_id=v_cash;
  select balance into v_bank_bal from public.money_balances where business_id=v_business and account_id=v_bank;
  if v_cash_bal <> 65000 or v_bank_bal <> 25000 then raise exception 'MONEY_BALANCE_INVALID'; end if;
end $$;

select 'MONEY_INTEGRATION_PASS' as status;
rollback;

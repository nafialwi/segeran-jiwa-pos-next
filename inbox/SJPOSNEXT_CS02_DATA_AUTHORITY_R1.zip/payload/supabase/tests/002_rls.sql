begin;

insert into public.businesses (id, code, display_name) values
('10000000-0000-0000-0000-000000000001','TESTA','Test A'),
('10000000-0000-0000-0000-000000000002','TESTB','Test B');
insert into public.profiles (id, auth_user_id, display_name, status) values
('20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001','Owner A','ACTIVE'),
('20000000-0000-0000-0000-000000000002','30000000-0000-0000-0000-000000000002','Kasir A','ACTIVE'),
('20000000-0000-0000-0000-000000000003','30000000-0000-0000-0000-000000000003','Owner B','ACTIVE');
insert into public.business_memberships (business_id, profile_id, role_code) values
('10000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000001','OWNER'),
('10000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000002','KASIR'),
('10000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000003','OWNER');
insert into public.locations (business_id, code, display_name, location_type) values
('10000000-0000-0000-0000-000000000001','TESTLOC','Test Location','STORE'),
('10000000-0000-0000-0000-000000000002','TESTLOC','Test Location','STORE');

set local role authenticated;
select set_config('request.jwt.claim.sub','30000000-0000-0000-0000-000000000002',true);

do $$
declare
  v_direct_write_blocked boolean := false;
begin
  if (select count(*) from public.businesses where code in ('TESTA','TESTB')) <> 1 then raise exception 'RLS_BUSINESS_SCOPE_INVALID'; end if;
  if (select count(*) from public.locations where code='TESTLOC') <> 1 then raise exception 'RLS_LOCATION_SCOPE_INVALID'; end if;
  begin
    insert into public.inventory_movements (business_id,movement_type,source_type,source_ref,reason_code)
    values ('10000000-0000-0000-0000-000000000001','BAD','TEST','BAD','BAD');
  exception when insufficient_privilege then
    v_direct_write_blocked := true;
  end;
  if not v_direct_write_blocked then raise exception 'RLS_DIRECT_FACT_WRITE_NOT_BLOCKED'; end if;
end $$;

reset role;
select 'RLS_INTEGRATION_PASS' as status;
rollback;

begin;

do $$
declare
  v_business uuid; v_gudang uuid; v_gerai uuid; v_item uuid; v_m2 uuid; v_retry uuid; v_q_gudang numeric; v_q_gerai numeric;
begin
  select id into v_business from public.businesses where code='SJ';
  select id into v_gudang from public.locations where business_id=v_business and code='GUDANG';
  select id into v_gerai from public.locations where business_id=v_business and code='GERAI';
  insert into public.stock_items (business_id,code,display_name,item_kind,base_unit) values (v_business,'TEST_ITEM_CS02','Test Item CS02','OTHER','PCS') returning id into v_item;
  perform private.record_inventory_movement(v_business,null,'itest-inv-open','OPENING','TEST','INV-OPEN','CS02_TEST',jsonb_build_array(jsonb_build_object('line_no',1,'stock_item_id',v_item,'location_id',v_gudang,'quantity_delta',10)),null);
  v_m2 := private.record_inventory_movement(v_business,null,'itest-inv-transfer','TRANSFER','TEST','INV-XFER','CS02_TEST',jsonb_build_array(jsonb_build_object('line_no',1,'stock_item_id',v_item,'location_id',v_gudang,'quantity_delta',-3),jsonb_build_object('line_no',2,'stock_item_id',v_item,'location_id',v_gerai,'quantity_delta',3)),null);
  v_retry := private.record_inventory_movement(v_business,null,'itest-inv-transfer','TRANSFER','TEST','INV-XFER','CS02_TEST',jsonb_build_array(jsonb_build_object('line_no',1,'stock_item_id',v_item,'location_id',v_gudang,'quantity_delta',-3),jsonb_build_object('line_no',2,'stock_item_id',v_item,'location_id',v_gerai,'quantity_delta',3)),null);
  if v_retry <> v_m2 then raise exception 'INVENTORY_REPLAY_ID_MISMATCH'; end if;
  select quantity into v_q_gudang from public.inventory_balances where business_id=v_business and stock_item_id=v_item and location_id=v_gudang;
  select quantity into v_q_gerai from public.inventory_balances where business_id=v_business and stock_item_id=v_item and location_id=v_gerai;
  if v_q_gudang <> 7 or v_q_gerai <> 3 then raise exception 'INVENTORY_BALANCE_INVALID'; end if;
end $$;

select 'INVENTORY_INTEGRATION_PASS' as status;
rollback;

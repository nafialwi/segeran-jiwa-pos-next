begin;

do $$
declare
  v_business uuid;
  v_hash text;
  v_result record;
  v_receipt uuid;
  v_target uuid := '40000000-0000-0000-0000-000000000001';
  v_conflict boolean := false;
begin
  select id into v_business from public.businesses where code='SJ';
  v_hash := private.payload_sha256('{"amount":1,"kind":"test"}'::jsonb);
  select * into v_result from private.lock_operation(v_business,'itest-idem','TEST_COMMAND',v_hash);
  if v_result.replay then raise exception 'IDEMPOTENCY_FALSE_REPLAY'; end if;
  v_receipt := private.record_operation_success(v_business,'itest-idem','TEST_COMMAND',v_hash,'TEST_RESULT',v_target,null);
  select * into v_result from private.lock_operation(v_business,'itest-idem','TEST_COMMAND',v_hash);
  if not v_result.replay or v_result.receipt_id <> v_receipt or v_result.result_id <> v_target then raise exception 'IDEMPOTENCY_REPLAY_INVALID'; end if;
  begin
    perform * from private.lock_operation(v_business,'itest-idem','TEST_COMMAND',repeat('a',64));
  exception when unique_violation then
    v_conflict := true;
  end;
  if not v_conflict then raise exception 'IDEMPOTENCY_CONFLICT_NOT_BLOCKED'; end if;
end $$;

select 'IDEMPOTENCY_INTEGRATION_PASS' as status;
rollback;

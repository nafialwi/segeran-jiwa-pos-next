# CS-02 — Database, Schema & Data Authority Foundation
## Design Spec — Approved Approach A

**Product:** Segeran Jiwa POS Next  
**Blueprint baseline:** v1.0 FINAL LOCK  
**Milestone:** CS-02 — Core System: Database, Schema & Data Authority Foundation  
**Status:** DESIGN APPROVED — awaiting user review of written spec before implementation plan  
**Date:** 2026-09-06

---

## 1. Purpose

CS-02 establishes the single authoritative database foundation for Segeran Jiwa POS Next before feature modules begin writing business data.

The goal is to ensure that later modules—Penjualan, Pembayaran, Persediaan, Keuangan, Shift, Pembelian, Produksi, Refund/Koreksi, Dashboard, and Laporan—cannot create independent or conflicting ledgers.

This milestone does **not** implement full business UI. It establishes the schema, authority boundaries, security model, idempotency primitives, migration discipline, and testable invariants required by the locked Blueprint.

---

## 2. Approved Architectural Direction

### 2.1 Dedicated Supabase Project
Create a new dedicated Supabase project for Segeran Jiwa POS Next.

Working name:
`segeran-jiwa-pos-next`

Rules:
- Do not reuse the older `totalku-core-dev` project.
- Region preference: Southeast Asia / Singapore when available.
- PostgreSQL is the primary business-data authority.
- Supabase Auth + RLS provide server-side identity and authorization.
- Browser local storage/cache is never the primary source of truth.

### 2.2 Authority-First Minimal Core
CS-02 builds the smallest database core that still prevents architectural drift.

It must establish:
- canonical business identity;
- user/profile foundation;
- official stock locations;
- migration/version authority;
- operation/idempotency registry;
- immutable activity/audit foundation;
- inventory movement authority;
- money movement/journal authority;
- reversal/reference primitives;
- permission/RLS skeleton;
- backup/restore baseline.

It deliberately avoids building the complete feature schema for every future module.

---

## 3. Core Invariants

The implementation must enforce these invariants:

1. No business stock change without a stock movement and explicit source/reason.
2. No business money balance change without a money movement/journal source.
3. No silent hard delete of completed business facts.
4. Reversal/correction must preserve the original business fact.
5. Important business commands must be idempotent.
6. A duplicate network retry or double tap must not create a second business transaction.
7. Gudang and Gerai remain separate official inventory locations.
8. Shift is operational context, not a second money ledger.
9. Dashboard and reporting read projections/facts; they do not become independent authorities.
10. Permission enforcement must exist server-side through RLS or controlled server functions, not only in UI.
11. Schema changes must be versioned and reproducible by migration.
12. Production secrets/service-role credentials must never be exposed to the browser.

---

## 4. Database Components

### 4.1 System / Schema Metadata
Foundation for:
- application database version;
- migration/checkpoint metadata;
- blueprint baseline reference;
- release compatibility metadata where needed.

The schema version introduced in CS-02 becomes the first real database authority baseline after CS-01 schema version 0.

### 4.2 Business / Store Identity
Single-business baseline for Segeran Jiwa POS Next.

Foundation fields may include:
- immutable internal UUID;
- business/store display identity;
- active status;
- created/updated timestamps.

No multi-tenant complexity is introduced unless required by the Blueprint later.

### 4.3 Users / Profiles
Supabase Auth remains authentication authority.

Application profile layer stores business-operational data such as:
- immutable profile UUID;
- auth user linkage;
- display name;
- status: active / leave / disabled;
- account metadata required by later permission milestones.

CS-02 creates the permission foundation, not the full User Management UI.

### 4.4 Official Locations
Seed official inventory locations:
- Gudang
- Gerai

Locations use immutable IDs.

Stock quantity is never treated as a manually editable truth field.

### 4.5 Operation / Idempotency Registry
Introduce a durable operation identity mechanism.

Minimum semantics:
- one idempotency key represents one important business command;
- exact successful operation cannot be committed twice;
- retry of the same operation returns/references the existing result;
- conflicting reuse of the same key with different semantic payload is rejected;
- failed operations do not create a false success record.

This primitive must later support offline local operation IDs/outbox reconciliation.

### 4.6 Activity / Audit Foundation
Create append-oriented activity records sufficient to trace:
- actor;
- operation;
- entity/reference;
- event type;
- timestamp;
- relevant metadata;
- reversal/correction relationships when applicable.

Audit history must not be disabled by business settings.

### 4.7 Inventory Movement Authority
Create the canonical stock movement foundation.

A stock movement must answer:
- what item/entity changed;
- from/to location when relevant;
- quantity delta;
- reason/source type;
- source document/reference;
- operation/idempotency reference;
- actor;
- effective timestamp.

The system may later expose read-model/current-balance projections, but movements remain the authoritative facts.

No generic unrestricted "stock in" write path is allowed.

### 4.8 Money Movement / Journal Authority
Create the canonical financial movement foundation.

It must support future buckets such as:
- Kas Utama;
- Kas Shift;
- Bank;
- QRIS Belum Cair;
- QRIS Sudah Cair;
- receivable/payable-related movements where later milestones require them.

Every movement must have:
- source;
- destination or accounting direction;
- amount;
- reason/business event;
- source reference;
- operation/idempotency reference;
- actor;
- timestamp.

Internal transfer must remain distinct from income/expense.

### 4.9 Reversal / Correction Primitive
Business facts are not erased.

The foundation must support:
- original reference;
- reversing/replacement reference;
- correction reason;
- actor;
- operation;
- timestamp.

Detailed refund/correction UI and domain behavior belong to later milestones.

---

## 5. RLS and Security Design

### 5.1 Default Posture
Use default-deny RLS for protected business tables.

### 5.2 Authentication Boundary
- Supabase Auth identifies users.
- Application profile/status determines business eligibility.
- Disabled users must not retain normal business access.
- UI hiding is not accepted as security enforcement.

### 5.3 Browser Credentials
Frontend may use only public client credentials suitable for browser use.

Service-role credentials:
- never committed to Git;
- never embedded in frontend build;
- only used in trusted server-side contexts if later required.

### 5.4 Privileged Writes
Where direct table writes would weaken invariants, use controlled database functions / RPC / server-side command boundaries instead of granting broad client mutation access.

---

## 6. Migration Discipline

All database DDL and seed changes must be reproducible from repository migrations.

Required characteristics:
- deterministic order;
- fresh empty database can reach current schema from migrations;
- migration naming/version convention is documented;
- no undocumented dashboard-only schema mutation;
- migrations are source-controlled;
- schema version/checkpoint is recorded;
- rollback/recovery limitations are documented where destructive down-migration is unsafe.

---

## 7. Data Flow Rules

### 7.1 Inventory
Business event
→ validated command
→ idempotency guard
→ stock movement fact
→ balance/read projection
→ UI/report reads projection

### 7.2 Money
Business/payment event
→ validated command
→ idempotency guard
→ money movement/journal fact
→ balance/read projection
→ UI/report reads projection

### 7.3 Offline Future Compatibility
Local command
→ local operation ID
→ outbox
→ reconnect
→ same server idempotency boundary
→ one successful commit only

CS-02 establishes the server-side primitive; offline UI/outbox implementation comes later.

---

## 8. Error Handling

Database command boundaries must return machine-readable and human-mappable failures for at least:

- duplicate/idempotency replay;
- conflicting idempotency payload;
- permission denied;
- inactive/disabled user;
- invalid source/reason;
- unknown location/reference;
- invalid amount/quantity;
- invariant violation;
- migration/schema mismatch;
- optimistic/concurrency conflict where applicable.

Failures must not leave partial authoritative state.

Where one business command affects multiple authority facts, the write must be atomic through a database transaction or equivalent trusted server transaction boundary.

---

## 9. Testing Strategy

### 9.1 Migration Tests
- fresh database migration succeeds;
- schema version is correct;
- expected core tables/functions/policies exist;
- seed of Gudang/Gerai is deterministic.

### 9.2 RLS Tests
Positive and negative cases:
- allowed user can perform permitted operation;
- unauthenticated request is denied;
- disabled user is denied;
- restricted user cannot bypass via direct API;
- client cannot access privileged secrets/paths.

### 9.3 Idempotency Tests
- same command + same key does not duplicate;
- same key + conflicting payload is rejected;
- retry after success returns existing result;
- failed operation does not create success receipt.

### 9.4 Inventory Invariant Tests
- stock cannot change without movement;
- official location separation is preserved;
- invalid movement is rejected;
- reversal leaves original fact intact.

### 9.5 Money Invariant Tests
- balance cannot change without journal/movement;
- internal transfer is not classified as revenue/expense;
- duplicate operation does not duplicate money movement;
- reversal/correction preserves original record.

### 9.6 Security Advisor
After DDL/RLS work:
- run Supabase security advisors;
- review relevant performance advisors;
- no unresolved critical security blocker at CS-02 lock.

### 9.7 Repository Verification
Existing canonical repository verification remains green.

---

## 10. Backup / Restore Baseline

CS-02 must define the zero-cost-first backup approach:

- logical PostgreSQL backup;
- off-site copy/retention;
- checksum;
- restore procedure;
- restore drill evidence;
- last-backup status integration contract for future System Health UI.

This milestone does not assume provider-managed PITR is sufficient.

---

## 11. Explicit Non-Scope

CS-02 does not implement the full UI or final business workflows for:

- Penjualan;
- checkout/payment UI;
- QRIS UI;
- Shift UI;
- Produk management UI;
- Pembelian UI;
- Produksi UI;
- Hutang/Kasbon UI;
- Refund/Koreksi UI;
- Dashboard;
- Laporan;
- Excel export;
- complete offline UX;
- production cutover.

Only the database/data-authority foundation required for these later modules is implemented.

---

## 12. Acceptance Gate

CS-02 may be declared `LOCKED` only if all are true:

1. Dedicated Segeran Jiwa POS Next Supabase project exists.
2. Full schema can be recreated from repository migrations.
3. Fresh migration verification passes.
4. RLS positive and negative tests pass.
5. Disabled/restricted users cannot bypass rules through direct API.
6. Idempotency tests pass.
7. Duplicate writes cannot create duplicate authoritative facts.
8. Inventory cannot change outside stock movement authority.
9. Money cannot change outside money movement/journal authority.
10. Original completed business facts are not hard-deleted.
11. Reversal/reference primitive passes tests.
12. Gudang and Gerai remain separate official locations.
13. No service-role secret is present in frontend/repository.
14. Supabase security advisor has no unresolved CS-02 blocker.
15. Backup/restore procedure and restore drill are documented/verified.
16. Existing repository verification remains PASS.
17. Checkpoint documentation records:
    - schema version;
    - migrations;
    - Supabase project identifier (non-secret);
    - test evidence;
    - release/rollback anchor;
    - NEXT ACTION.

---

## 13. Clean-and-Clear Execution Rule

Before any CS-02 package is handed to the user:

1. inspect the current canonical `main`;
2. verify CS-01 remains clean;
3. implement only CS-02 scope;
4. run migrations/tests locally or in isolated test environment;
5. run canonical repository verification;
6. run security advisor review;
7. inspect diff for scope creep;
8. create one guarded Mobile Inbox package;
9. only then ask user to upload the ZIP;
10. no repeated trial-and-error upload should be used as the normal development method.

---

## 14. Next Step

After the user reviews and approves this written CS-02 Design Spec:

1. create the detailed CS-02 Implementation Plan;
2. map implementation tasks to TDD/verification gates;
3. establish rollback/checkpoint strategy;
4. only after Implementation Plan approval begin CS-02 implementation.


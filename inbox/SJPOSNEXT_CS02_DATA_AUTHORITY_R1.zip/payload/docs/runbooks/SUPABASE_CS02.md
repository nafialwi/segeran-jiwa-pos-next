# Supabase CS-02 Runbook

## Authority

- Product: Segeran Jiwa POS Next
- Project: `segeran-jiwa-pos-next`
- Project ref: `pkynjaqrxhhnnfuaxoqp`
- Region: `ap-southeast-1` (Singapore)
- Plan: Free
- Primary authority: PostgreSQL/Supabase
- Schema version: `1`
- DDL: versioned migrations only
- Secrets: never commit or place in Mobile Inbox payloads

## Data-authority rules

- Stock changes only through inventory movement facts.
- Money changes only through money movement facts.
- Completed facts are immutable; corrections use new reversal facts.
- Important writes are idempotent.
- Generic ledger recorders are in the non-exposed `private` schema and are not executable by browser client roles.
- Browser roles receive explicit read grants plus RLS; direct ledger writes remain denied.

## Hosted verification order

1. List migrations.
2. Confirm schema version.
3. Run SQL tests `001` through `006` inside transactions ending in `rollback`.
4. List tables and deterministic reference seeds.
5. Run Security Advisor.
6. Run Performance Advisor.
7. Confirm no test fixtures persist.
8. Record non-secret evidence in the checkpoint report.

## Backup baseline

CS-02 contains no real production business transactions yet. The initial hosted build is therefore the foundation rebuild drill: a fresh dedicated project was reconstructed from source-controlled migrations plus deterministic seeds, without imported legacy schema.

Before real production business data is introduced, backup health must require:

- logical PostgreSQL export;
- off-site retained copy;
- SHA-256 checksum;
- dated backup manifest;
- restore verification before the backup is considered healthy.

Do not rely on paid PITR as the zero-cost baseline.

## Recovery

- Source rollback anchor before CS-02: `c7bce7498b27ea6bd5f8c1981597f068ca4f6f53`.
- Database corrections are fix-forward migrations; do not rewrite applied hosted migration history.
- Never switch to `totalku-core-dev` as an implicit fallback.

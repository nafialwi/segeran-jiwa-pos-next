from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
MIGRATIONS = ROOT / 'supabase' / 'migrations'
SQL_TESTS = ROOT / 'supabase' / 'tests'
EXPECTED_MIGRATIONS = [
    '202609060001_cs02_system_metadata.sql',
    '202609060002_cs02_identity_and_reference.sql',
    '202609060003_cs02_idempotency_and_audit.sql',
    '202609060004_cs02_inventory_authority.sql',
    '202609060005_cs02_money_authority.sql',
    '202609060006_cs02_rls_and_grants.sql',
    '202609060007_cs02_explicit_read_grants.sql',
    '202609060008_cs02_restrict_auto_rls_helper.sql',
    '202609060009_cs02_performance_hardening.sql',
]
EXPECTED_SQL_TESTS = [f'{i:03d}_{name}.sql' for i, name in [
    (1,'foundation_assertions'), (2,'rls'), (3,'idempotency'), (4,'inventory'), (5,'money'), (6,'immutability')
]]

class Cs02MigrationTests(unittest.TestCase):
    def test_expected_files_exist(self):
        self.assertEqual(sorted(p.name for p in MIGRATIONS.glob('*.sql')), sorted(EXPECTED_MIGRATIONS))
        self.assertEqual(sorted(p.name for p in SQL_TESTS.glob('*.sql')), sorted(EXPECTED_SQL_TESTS))

    def test_no_secret_assignments(self):
        text = '\n'.join((MIGRATIONS / n).read_text('utf-8') for n in EXPECTED_MIGRATIONS).lower()
        for token in ['supabase_service_role_key=', 'database_url=', 'postgres_password=', 'access_token=']:
            self.assertNotIn(token, text)

    def test_authority_objects_exist_in_source(self):
        text = '\n'.join((MIGRATIONS / n).read_text('utf-8') for n in EXPECTED_MIGRATIONS).lower()
        for token in ['private.schema_versions','public.operation_receipts','public.audit_events','public.inventory_movements','public.inventory_movement_lines','public.inventory_balances','public.money_movements','public.money_balances','enable row level security']:
            self.assertIn(token, text)

    def test_fact_tables_do_not_cascade(self):
        text = '\n'.join((MIGRATIONS / n).read_text('utf-8') for n in EXPECTED_MIGRATIONS).lower()
        for table in ['operation_receipts','audit_events','inventory_movements','inventory_movement_lines','money_movements']:
            m = re.search(rf'create table public\.{table}.*?(?=create table|create view|create trigger|$)', text, re.S)
            self.assertIsNotNone(m, table)
            self.assertNotIn('on delete cascade', m.group(0))

    def test_sql_tests_are_transactional(self):
        for name in EXPECTED_SQL_TESTS:
            text = (SQL_TESTS / name).read_text('utf-8').strip().lower()
            self.assertTrue(text.startswith('begin;'), name)
            self.assertTrue(text.endswith('rollback;'), name)

if __name__ == '__main__':
    unittest.main()

# ROADMAP PROGRESS v1.0

## Purpose

This file is the project-management authority for weighted progress. It does **not** override Blueprint business rules, data authority, permissions, money semantics, stock semantics, or Change Control.

The weighting is fixed at 100%. Future milestone decomposition may split a bucket into smaller milestones, but the bucket's total weight must remain unchanged unless the Owner explicitly approves a roadmap revision.

## Weighted roadmap

| Delivery bucket | Weight | Current completion | Earned progress |
|---|---:|---:|---:|
| Blueprint / Product & Design Authority | 10% | 100% | 10.0% |
| CS-01 — Repository, Mobile Inbox & Automation Foundation | 10% | 100% | 10.0% |
| CS-02 — Database, Schema & Data Authority Foundation | 12% | 0% | 0.0% |
| Identity, Device Control, Permissions, Settings & Production Design System | 10% | 0% | 0.0% |
| Sales, Checkout, Payment Engine & Manual QRIS | 12% | 0% | 0.0% |
| Shift, Cash, Handover & Reconciliation | 10% | 0% | 0.0% |
| Inventory, Gudang/Gerai, Purchase, Supplier & Simple Production | 14% | 0% | 0.0% |
| Expense, Customer Debt, Employee Kasbon & Finance Engine | 10% | 0% | 0.0% |
| History, Reversal/Refund, Reports & Excel | 7% | 0% | 0.0% |
| Messages/Attention/Activity, Offline, Backup/Restore, Health/Usage & Cutover Hardening | 5% | 0% | 0.0% |
| **TOTAL** | **100%** |  | **20.0%** |

## Rules for reporting progress

1. Report **milestone progress** separately from **whole-project weighted progress**.
2. A bucket earns its full weight only when its acceptance gate is LOCKED.
3. Partial implementation may be reported inside the active milestone, but whole-project earned progress must be calculated consistently from the approved bucket weight.
4. Old failed experiments do not reduce earned progress after the corresponding defect is corrected and the gate passes.
5. No progress may be claimed from visual mockups alone once implementation for that bucket has started.
6. Cutover readiness is separate from weighted progress; 100% weighted progress requires final cutover hardening acceptance.

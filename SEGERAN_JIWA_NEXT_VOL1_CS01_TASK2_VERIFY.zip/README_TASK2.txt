Segeran Jiwa Next Vol. 1 — CS-01 Task 2 transport package

Purpose:
- preflight-verifies Task 1
- proves TDD RED for repository guard/composite verify
- creates scripts/repo-guard.mjs and scripts/verify.mjs
- runs canonical npm run verify
- commits and pushes only after PASS

Run only from work/cs-01 in Codespaces.

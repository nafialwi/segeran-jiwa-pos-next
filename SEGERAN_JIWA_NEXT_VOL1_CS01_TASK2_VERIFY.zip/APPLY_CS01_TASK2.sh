#!/usr/bin/env bash
set -euo pipefail

BRANCH="work/cs-01"
TRANSPORT_SCRIPT="APPLY_CS01_TASK2.sh"
TRANSPORT_ZIP="SEGERAN_JIWA_NEXT_VOL1_CS01_TASK2_VERIFY.zip"

echo "== Segeran Jiwa Next Vol. 1 | CS-01 Task 2 =="

if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "ERROR: Jalankan dari root repository." >&2
  exit 2
fi

current_branch="$(git branch --show-current)"
if [[ "$current_branch" != "$BRANCH" ]]; then
  echo "ERROR: Branch harus $BRANCH, sekarang: $current_branch" >&2
  exit 3
fi

if [[ -n "$(git status --porcelain)" ]]; then
  echo "ERROR: Working tree tidak bersih sebelum Task 2." >&2
  git status --short
  exit 4
fi

node_major="$(node -p 'process.versions.node.split(".")[0]')"
if [[ "$node_major" != "24" ]]; then
  if command -v nvm >/dev/null 2>&1; then
    nvm use 24
  elif [[ -s "${NVM_DIR:-$HOME/.nvm}/nvm.sh" ]]; then
    # shellcheck disable=SC1090
    source "${NVM_DIR:-$HOME/.nvm}/nvm.sh"
    nvm use 24
  else
    echo "ERROR: Node 24 tidak aktif." >&2
    exit 5
  fi
fi

if [[ ! -f package-lock.json ]]; then
  echo "ERROR: package-lock.json Task 1 tidak ditemukan." >&2
  exit 6
fi

BASE_COMMIT="$(git rev-parse HEAD)"
echo "TASK1_BASE_COMMIT=$BASE_COMMIT"
echo "TASK1_PREFLIGHT=RUNNING"

# Re-verify Task 1 foundation before modifying anything.
npm run format:check
npm run lint
npm run typecheck
npm run test:js
npm run build
git diff --check

echo "TASK1_PREFLIGHT=PASS"

mkdir -p scripts

cat > tests/repo-guard.test.mjs <<'JS'
import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { findForbiddenTrackedPaths } from '../scripts/repo-guard.mjs';

const pkg = JSON.parse(
  readFileSync(new URL('../package.json', import.meta.url), 'utf8'),
);

describe('repository foundation', () => {
  it('pins the composite verify command', () => {
    expect(pkg.scripts.verify).toBe('node scripts/verify.mjs');
  });

  it('keeps Python tests inside the standard test surface', () => {
    expect(pkg.scripts['test:py']).toContain('unittest discover');
  });
});

describe('repository guard', () => {
  it('rejects secret-like tracked paths while allowing .env.example', () => {
    const violations = findForbiddenTrackedPaths([
      '.env',
      '.env.local',
      '.env.example',
      'config/client-secret.json',
      'src/app.ts',
    ]);

    expect(violations).toEqual([
      '.env',
      '.env.local',
      'config/client-secret.json',
    ]);
  });

  it('requires every canonical quality phase in verify.mjs', () => {
    const source = readFileSync(
      new URL('../scripts/verify.mjs', import.meta.url),
      'utf8',
    );

    for (const command of [
      'node scripts/repo-guard.mjs',
      'npm run format:check',
      'npm run lint',
      'npm run typecheck',
      'npm run test:js',
      'npm run test:py',
      'npm run build',
      'git diff --check',
    ]) {
      expect(source).toContain(command);
    }
  });
});
JS

echo "TASK2_TDD_RED=RUNNING"
set +e
npm run test:js -- tests/repo-guard.test.mjs
red_status=$?
set -e
if [[ "$red_status" -eq 0 ]]; then
  echo "ERROR: TDD RED tidak terjadi; test baru seharusnya gagal sebelum implementasi." >&2
  exit 10
fi
echo "TASK2_TDD_RED=CONFIRMED"

cat > scripts/repo-guard.mjs <<'JS'
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

export function findForbiddenTrackedPaths(paths) {
  return paths.filter((path) => {
    const lower = path.toLowerCase();
    if (lower === '.env.example') return false;
    if (lower === '.env' || lower.startsWith('.env.')) return true;
    return (
      lower.includes('secret') ||
      lower.endsWith('.pem') ||
      lower.endsWith('.key') ||
      lower.endsWith('.p12') ||
      lower.endsWith('.pfx')
    );
  });
}

function main() {
  const tracked = execFileSync('git', ['ls-files'], {
    encoding: 'utf8',
  })
    .split('\n')
    .filter(Boolean);

  const violations = findForbiddenTrackedPaths(tracked);
  if (violations.length > 0) {
    console.error('Forbidden tracked paths:');
    for (const path of violations) console.error(`- ${path}`);
    process.exit(1);
  }
}

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  main();
}
JS

cat > scripts/verify.mjs <<'JS'
import { spawnSync } from 'node:child_process';

const commands = [
  ['node', ['scripts/repo-guard.mjs']],
  ['npm', ['run', 'format:check']],
  ['npm', ['run', 'lint']],
  ['npm', ['run', 'typecheck']],
  ['npm', ['run', 'test:js']],
  ['npm', ['run', 'test:py']],
  ['npm', ['run', 'build']],
  ['git', ['diff', '--check']],
];

for (const [command, args] of commands) {
  const label = [command, ...args].join(' ');
  console.log(`\n==> ${label}`);
  const result = spawnSync(command, args, {
    stdio: 'inherit',
    shell: false,
  });

  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status ?? 1);
}
JS

# Normalize source formatting before the canonical verification gate.
npx prettier --write tests/repo-guard.test.mjs scripts/repo-guard.mjs scripts/verify.mjs

echo "TASK2_GREEN_VERIFY=RUNNING"
npm run verify
echo "TASK2_GREEN_VERIFY=PASS"

# Transport artifacts must never become repository source.
rm -f "$TRANSPORT_SCRIPT" "$TRANSPORT_ZIP"

git add scripts tests package.json package-lock.json
if git diff --cached --quiet; then
  echo "ERROR: Task 2 menghasilkan nol perubahan staged." >&2
  exit 11
fi

git commit -m "test(cs-01): add canonical composite verification"
git push origin "$BRANCH"

echo
echo "TASK2_RESULT=PASS"
echo "BRANCH=$(git branch --show-current)"
echo "BASE_COMMIT=$BASE_COMMIT"
echo "COMMIT=$(git rev-parse HEAD)"
echo "REMOTE=$(git remote get-url origin)"
echo "WORKTREE_CLEAN=$([[ -z \"$(git status --porcelain)\" ]] && echo yes || echo no)"

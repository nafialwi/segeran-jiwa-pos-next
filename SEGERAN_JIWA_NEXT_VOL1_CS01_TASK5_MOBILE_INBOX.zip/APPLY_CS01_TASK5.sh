#!/usr/bin/env bash
set -euo pipefail

EXPECTED_BRANCH="work/cs-01"
ROOT="$(git rev-parse --show-toplevel)"
cd "$ROOT"

echo "TASK5_PREFLIGHT=RUNNING"
git fetch origin work/cs-01 >/dev/null 2>&1 || true

BRANCH="$(git branch --show-current)"
if [ "$BRANCH" != "$EXPECTED_BRANCH" ]; then
  echo "ERROR: expected branch $EXPECTED_BRANCH, got $BRANCH"
  exit 1
fi

if [ -n "$(git status --porcelain)" ]; then
  echo "ERROR: working tree must be clean before Task 5"
  git status --short
  exit 1
fi

for f in \
  ".github/workflows/ci.yml" \
  ".github/pull_request_template.md" \
  "tools/mobile_inbox/contract.py" \
  "tools/mobile_inbox/intake.py" \
  "tools/mobile_inbox/package_manifest.schema.json"
do
  if [ ! -f "$f" ]; then
    echo "ERROR: Task 4/3 prerequisite missing: $f"
    exit 1
  fi
done

if ! grep -q "canonical-verify" .github/workflows/ci.yml; then
  echo "ERROR: Task 4 canonical status workflow missing"
  exit 1
fi

echo "TASK5_PREFLIGHT=PASS"

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# RED: add only the test first.
mkdir -p tests
cp "$PACK_DIR/payload/tests/test_transport_guard.py" tests/test_transport_guard.py

set +e
RED_OUT="$(mktemp)"
npm run test:py >"$RED_OUT" 2>&1
RED_STATUS=$?
set -e

cat "$RED_OUT"
if [ "$RED_STATUS" -eq 0 ]; then
  echo "ERROR: Task 5 TDD RED expected failure before transport_guard implementation"
  exit 1
fi
if ! grep -Eq "No module named ['\"]?tools\.mobile_inbox\.transport_guard|cannot import name|ModuleNotFoundError" "$RED_OUT"; then
  echo "ERROR: Task 5 failed, but not for expected missing transport_guard reason"
  exit 1
fi
rm -f "$RED_OUT"
echo "TASK5_TDD_RED=CONFIRMED"

# GREEN implementation.
mkdir -p tools/mobile_inbox
cp "$PACK_DIR/payload/tools/mobile_inbox/transport_guard.py" tools/mobile_inbox/transport_guard.py
cp "$PACK_DIR/payload/tools/mobile_inbox/mobile-inbox-trigger.yml" tools/mobile_inbox/mobile-inbox-trigger.yml

# Static dispatcher safety gates.
python3 - <<'PY'
from pathlib import Path
text = Path("tools/mobile_inbox/mobile-inbox-trigger.yml").read_text()
required = [
    "branches:",
    "- mobile-inbox",
    "'inbox/*.zip'",
    "contents: read",
    "actions: write",
    "--ref main",
    'transport_sha="$TRANSPORT_SHA"',
]
for token in required:
    if token not in text:
        raise SystemExit(f"dispatcher missing required token: {token}")
for forbidden in ["contents: write", "pull-requests: write"]:
    if forbidden in text:
        raise SystemExit(f"dispatcher has forbidden permission: {forbidden}")
print("TASK5_DISPATCHER_STATIC=PASS")
PY

npm run verify
git diff --check
echo "TASK5_LOCAL_VERIFY=PASS"

# Prepare exact orphan transport content in an isolated temporary worktree.
TMP="$(mktemp -d)"
cleanup() {
  git worktree remove --force "$TMP" >/dev/null 2>&1 || true
  if [ -n "${ORPHAN_LOCAL:-}" ]; then
    git branch -D "$ORPHAN_LOCAL" >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT

REMOTE_EXISTS=0
if git ls-remote --exit-code --heads origin mobile-inbox >/dev/null 2>&1; then
  REMOTE_EXISTS=1
fi

if [ "$REMOTE_EXISTS" -eq 0 ]; then
  ORPHAN_LOCAL="task5-mobile-inbox-$$"
  git worktree add --detach "$TMP" HEAD >/dev/null
  git -C "$TMP" switch --orphan "$ORPHAN_LOCAL" >/dev/null
  git -C "$TMP" rm -rf . >/dev/null 2>&1 || true

  mkdir -p "$TMP/.github/workflows" "$TMP/inbox" "$TMP/processed" "$TMP/reports"
  cp "$ROOT/tools/mobile_inbox/mobile-inbox-trigger.yml" "$TMP/.github/workflows/mobile-inbox-trigger.yml"

  cat > "$TMP/inbox/README.md" <<'EOF'
Upload satu package ZIP hanya ke folder ini melalui GitHub Web.
Jangan upload source manual ke main.
Satu commit upload normal hanya boleh mengubah satu file ZIP di folder inbox.
Jika automation gagal, baca report terlebih dahulu sebelum retry.
EOF

  cat > "$TMP/processed/README.md" <<'EOF'
Folder ini menyimpan receipt JSON untuk package_id yang sudah sukses diproses.
Receipt adalah audit state; jangan diedit manual pada workflow normal.
EOF

  cat > "$TMP/reports/README.md" <<'EOF'
Folder ini menyimpan report intake yang dihasilkan automation.
Report gagal tidak berarti source berubah; lihat status dan pesan error sebelum retry.
EOF

  git -C "$TMP" add .github inbox processed reports
  git -C "$TMP" commit -m "chore(cs-01): initialize mobile inbox transport branch" >/dev/null
  git -C "$TMP" push origin HEAD:mobile-inbox >/dev/null
  echo "TASK5_MOBILE_INBOX_CREATED=yes"
else
  echo "TASK5_MOBILE_INBOX_CREATED=no"
  echo "TASK5_MOBILE_INBOX_RETRY=VERIFY_EXISTING"
fi

git fetch origin mobile-inbox >/dev/null

EXPECTED_LIST="$(printf '%s\n' \
  '.github/workflows/mobile-inbox-trigger.yml' \
  'inbox/README.md' \
  'processed/README.md' \
  'reports/README.md')"
ACTUAL_LIST="$(git ls-tree -r --name-only origin/mobile-inbox | sort)"

if [ "$ACTUAL_LIST" != "$EXPECTED_LIST" ]; then
  echo "ERROR: remote mobile-inbox contains unexpected files"
  echo "EXPECTED:"
  printf '%s\n' "$EXPECTED_LIST"
  echo "ACTUAL:"
  printf '%s\n' "$ACTUAL_LIST"
  exit 1
fi

git show origin/mobile-inbox:.github/workflows/mobile-inbox-trigger.yml > /tmp/mobile-inbox-trigger.yml
if ! cmp -s tools/mobile_inbox/mobile-inbox-trigger.yml /tmp/mobile-inbox-trigger.yml; then
  echo "ERROR: deployed dispatcher differs from canonical template"
  exit 1
fi

python3 - <<'PY'
from pathlib import Path
text = Path("/tmp/mobile-inbox-trigger.yml").read_text()
if "contents: read" not in text or "actions: write" not in text:
    raise SystemExit("deployed dispatcher permissions incomplete")
if "contents: write" in text:
    raise SystemExit("deployed dispatcher must not have contents: write")
print("TASK5_REMOTE_TRANSPORT=PASS")
PY

# Commit canonical assets only after remote transport verification.
git add tools/mobile_inbox/mobile-inbox-trigger.yml tools/mobile_inbox/transport_guard.py tests/test_transport_guard.py
git diff --cached --check

if git diff --cached --quiet; then
  echo "ERROR: no Task 5 canonical change to commit"
  exit 1
fi

git commit -m "feat(cs-01): add guarded mobile inbox dispatcher"
git push origin work/cs-01

echo "TASK5_RESULT=PASS"
echo "BRANCH=$(git branch --show-current)"
echo "COMMIT=$(git rev-parse HEAD)"
echo "MOBILE_INBOX_COMMIT=$(git rev-parse origin/mobile-inbox)"
echo "WORKTREE_CLEAN=$([ -z "$(git status --porcelain)" ] && echo yes || echo no)"

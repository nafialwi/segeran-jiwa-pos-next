#!/usr/bin/env bash
set -euo pipefail

EXPECTED_BASE="550c6feb53893d16bf161b4c87108ccb808fa21e"
EXPECTED_BRANCH="work/cs-01"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD_DIR="$SCRIPT_DIR/payload"

branch="$(git branch --show-current)"
if [[ "$branch" != "$EXPECTED_BRANCH" ]]; then
  echo "ERROR: expected branch $EXPECTED_BRANCH, got $branch" >&2
  exit 1
fi

head_commit="$(git rev-parse HEAD)"
if [[ "$head_commit" != "$EXPECTED_BASE" ]]; then
  echo "ERROR: Task 3 must start from Task 2 final commit $EXPECTED_BASE" >&2
  echo "Current HEAD: $head_commit" >&2
  exit 1
fi

if [[ -n "$(git status --porcelain)" ]]; then
  echo "ERROR: working tree must be clean before Task 3" >&2
  git status --short >&2
  exit 1
fi

echo "TASK3_PREFLIGHT=PASS"
echo "TASK3_BASE=$head_commit"

# TDD RED: install only the new tests first. Production validator must not exist yet.
cp "$PAYLOAD_DIR/tests/test_mobile_inbox.py" tests/test_mobile_inbox.py

set +e
npm run test:py > /tmp/cs01-task3-red.log 2>&1
red_status=$?
set -e

cat /tmp/cs01-task3-red.log

if [[ "$red_status" -eq 0 ]]; then
  echo "ERROR: Task 3 RED gate unexpectedly passed before validator implementation" >&2
  exit 1
fi

if ! grep -Eq "No module named 'tools\.mobile_inbox'|ModuleNotFoundError.*tools\.mobile_inbox" /tmp/cs01-task3-red.log; then
  echo "ERROR: Task 3 failed, but not for the expected missing-validator reason" >&2
  exit 1
fi

echo "TASK3_TDD_RED=CONFIRMED"

# GREEN: apply the contract, schema metadata and CLI wrapper.
mkdir -p tools/mobile_inbox
cp "$PAYLOAD_DIR/tools/mobile_inbox/contract.py" tools/mobile_inbox/contract.py
cp "$PAYLOAD_DIR/tools/mobile_inbox/intake.py" tools/mobile_inbox/intake.py
cp "$PAYLOAD_DIR/tools/mobile_inbox/package_manifest.schema.json" tools/mobile_inbox/package_manifest.schema.json

# Keep JSON formatting canonical for the repository quality gate.
npx prettier --write tools/mobile_inbox/package_manifest.schema.json

echo "TASK3_GREEN_VERIFY=RUNNING"
npm run verify
echo "TASK3_GREEN_VERIFY=PASS"

git add tools/mobile_inbox tests/test_mobile_inbox.py
git diff --cached --check

git commit -m "feat(cs-01): lock safe mobile inbox package contract"
git push origin work/cs-01

echo "TASK3_RESULT=PASS"
echo "BRANCH=$(git branch --show-current)"
echo "COMMIT=$(git rev-parse HEAD)"
echo "WORKTREE_CLEAN=$([[ -z "$(git status --porcelain)" ]] && echo yes || echo no)"

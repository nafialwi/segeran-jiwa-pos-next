CS-01 Task 3 — Safe ZIP Validator
Run APPLY_CS01_TASK3.sh only from work/cs-01 at the exact Task 2 final commit.

#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel)"
cd "$ROOT"

echo "TASK7_PREFLIGHT=RUNNING"

if [ "$(git branch --show-current)" != "work/cs-01" ]; then
  echo "ERROR: Task 7 must run on work/cs-01"
  exit 1
fi

if [ -n "$(git status --porcelain)" ]; then
  echo "ERROR: Task 7 requires a clean working tree"
  git status --short
  exit 1
fi

for f in \
  ".github/workflows/ci.yml" \
  ".github/workflows/mobile-inbox-worker.yml" \
  "tools/mobile_inbox/mobile-inbox-trigger.yml" \
  "tools/mobile_inbox/transport_guard.py"
do
  test -f "$f" || { echo "ERROR: Task 6/5 prerequisite missing: $f"; exit 1; }
done

git fetch origin work/cs-01 mobile-inbox >/dev/null

if [ "$(git rev-parse HEAD)" != "$(git rev-parse origin/work/cs-01)" ]; then
  echo "ERROR: local work/cs-01 is not equal to origin/work/cs-01"
  exit 1
fi

git show origin/mobile-inbox:.github/workflows/mobile-inbox-trigger.yml > /tmp/task7-trigger.yml
cmp -s tools/mobile_inbox/mobile-inbox-trigger.yml /tmp/task7-trigger.yml || {
  echo "ERROR: dispatcher drift before Task 7"
  exit 1
}

REPO="$(gh repo view --json nameWithOwner -q .nameWithOwner)"
HEAD_SHA="$(git rev-parse HEAD)"
STATUS="$(
  gh api "repos/$REPO/commits/$HEAD_SHA/status" \
    --jq '[.statuses[] | select(.context == "canonical-verify")][0].state // ""' \
    2>/dev/null || true
)"
if [ "$STATUS" != "success" ]; then
  echo "ERROR: Task 6 canonical-verify is not success on current HEAD"
  echo "STATUS=${STATUS:-missing}"
  exit 1
fi

echo "TASK6_REVERIFY=PASS"
echo "TASK7_PREFLIGHT=PASS"

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p tests
cp "$PACK_DIR/payload/tests/docs-runbook.test.mjs" tests/docs-runbook.test.mjs

set +e
RED_OUT="$(mktemp)"
npm run test:js -- tests/docs-runbook.test.mjs >"$RED_OUT" 2>&1
RED_STATUS=$?
set -e
cat "$RED_OUT"
if [ "$RED_STATUS" -eq 0 ]; then
  echo "ERROR: Task 7 TDD RED expected docs test to fail before runbooks exist"
  exit 1
fi
if ! grep -Eq "ENOENT|no such file|MOBILE_INBOX|RECOVERY|WORKFLOW_PROFILE" "$RED_OUT"; then
  echo "ERROR: Task 7 RED failed for an unexpected reason"
  exit 1
fi
rm -f "$RED_OUT"
echo "TASK7_TDD_RED=CONFIRMED"

mkdir -p docs/runbooks docs/blueprint docs/checkpoints
cp "$PACK_DIR/payload/docs/runbooks/MOBILE_INBOX.md" docs/runbooks/MOBILE_INBOX.md
cp "$PACK_DIR/payload/docs/runbooks/RECOVERY.md" docs/runbooks/RECOVERY.md
cp "$PACK_DIR/payload/docs/blueprint/15_WORKFLOW_PROFILE.md" docs/blueprint/15_WORKFLOW_PROFILE.md
cp "$PACK_DIR/payload/docs/checkpoints/17_PROJECT_STATE_BP_LOCKED_SNAPSHOT.md" docs/checkpoints/17_PROJECT_STATE_BP_LOCKED_SNAPSHOT.md
cp "$PACK_DIR/payload/docs/checkpoints/18_CHECKPOINT_REPORT_TEMPLATE.md" docs/checkpoints/18_CHECKPOINT_REPORT_TEMPLATE.md

npx prettier --write \
  docs/runbooks/MOBILE_INBOX.md \
  docs/runbooks/RECOVERY.md \
  docs/blueprint/15_WORKFLOW_PROFILE.md \
  docs/checkpoints/17_PROJECT_STATE_BP_LOCKED_SNAPSHOT.md \
  docs/checkpoints/18_CHECKPOINT_REPORT_TEMPLATE.md \
  tests/docs-runbook.test.mjs

npm run test:js -- tests/docs-runbook.test.mjs
npm run verify
git diff --check
echo "TASK7_LOCAL_VERIFY=PASS"

git add docs tests/docs-runbook.test.mjs
git diff --cached --check
git commit -m "docs(cs-01): lock Android-first intake runbooks"
git push origin work/cs-01

HEAD_SHA="$(git rev-parse HEAD)"
RUN_ID=""

for _ in $(seq 1 60); do
  RUN_ID="$(
    gh api "repos/$REPO/actions/runs?branch=work%2Fcs-01&event=push&per_page=50" \
      --jq ".workflow_runs[] | select(.head_sha == \"$HEAD_SHA\" and .name == \"canonical-ci\") | .id" \
      2>/dev/null | head -n1 || true
  )"
  [ -n "$RUN_ID" ] && break
  sleep 5
done

if [ -z "$RUN_ID" ]; then
  echo "ERROR: canonical-ci run not found for Task 7 commit"
  exit 1
fi

echo "TASK7_CANONICAL_RUN_ID=$RUN_ID"
if ! gh run watch "$RUN_ID" --exit-status; then
  echo "TASK7_CANONICAL_CI=FAIL"
  gh run view "$RUN_ID" --log-failed || true
  exit 1
fi
echo "TASK7_CANONICAL_CI=PASS"

STATUS=""
for _ in $(seq 1 24); do
  STATUS="$(
    gh api "repos/$REPO/commits/$HEAD_SHA/status" \
      --jq '[.statuses[] | select(.context == "canonical-verify")][0].state // ""' \
      2>/dev/null || true
  )"
  [ "$STATUS" = "success" ] && break
  [ "$STATUS" = "failure" ] && break
  sleep 5
done

echo "TASK7_CANONICAL_STATUS=${STATUS:-missing}"
[ "$STATUS" = "success" ] || exit 1

echo "TASK7_RESULT=PASS"
echo "BRANCH=$(git branch --show-current)"
echo "COMMIT=$HEAD_SHA"
echo "WORKTREE_CLEAN=$([ -z "$(git status --porcelain)" ] && echo yes || echo no)"

#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel)"
cd "$ROOT"

echo "TASK6_PREFLIGHT=RUNNING"

if [ "$(git branch --show-current)" != "work/cs-01" ]; then
  echo "ERROR: Task 6 must run on work/cs-01"
  exit 1
fi

if [ -n "$(git status --porcelain)" ]; then
  echo "ERROR: Task 6 requires a clean working tree"
  git status --short
  exit 1
fi

for f in \
  ".github/workflows/ci.yml" \
  "tools/mobile_inbox/mobile-inbox-trigger.yml" \
  "tools/mobile_inbox/transport_guard.py" \
  "tools/mobile_inbox/contract.py" \
  "tools/mobile_inbox/intake.py"
do
  test -f "$f" || { echo "ERROR: prerequisite missing: $f"; exit 1; }
done

git fetch origin mobile-inbox work/cs-01 >/dev/null

EXPECTED_LIST="$(printf '%s\n' \
  '.github/workflows/mobile-inbox-trigger.yml' \
  'inbox/README.md' \
  'processed/README.md' \
  'reports/README.md')"
ACTUAL_LIST="$(git ls-tree -r --name-only origin/mobile-inbox | sort)"
if [ "$ACTUAL_LIST" != "$EXPECTED_LIST" ]; then
  echo "ERROR: Task 5 mobile-inbox branch is not the expected transport-only state"
  printf '%s\n' "$ACTUAL_LIST"
  exit 1
fi

git show origin/mobile-inbox:.github/workflows/mobile-inbox-trigger.yml > /tmp/task6-deployed-trigger.yml
cmp -s tools/mobile_inbox/mobile-inbox-trigger.yml /tmp/task6-deployed-trigger.yml || {
  echo "ERROR: Task 5 dispatcher drift detected"
  exit 1
}

echo "TASK5_REVERIFY=PASS"
echo "TASK6_PREFLIGHT=PASS"

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p tests
cp "$PACK_DIR/payload/tests/worker-contract.test.mjs" tests/worker-contract.test.mjs

set +e
RED_OUT="$(mktemp)"
npm run test:js -- tests/worker-contract.test.mjs >"$RED_OUT" 2>&1
RED_STATUS=$?
set -e
cat "$RED_OUT"
if [ "$RED_STATUS" -eq 0 ]; then
  echo "ERROR: Task 6 TDD RED expected worker-contract test to fail before workflow exists"
  exit 1
fi
if ! grep -Eq "ENOENT|no such file|mobile-inbox-worker" "$RED_OUT"; then
  echo "ERROR: Task 6 RED failed for an unexpected reason"
  exit 1
fi
rm -f "$RED_OUT"
echo "TASK6_TDD_RED=CONFIRMED"

mkdir -p .github/workflows
cp "$PACK_DIR/payload/.github/workflows/mobile-inbox-worker.yml" .github/workflows/mobile-inbox-worker.yml

npx prettier --write .github/workflows/mobile-inbox-worker.yml tests/worker-contract.test.mjs

npm run test:js -- tests/worker-contract.test.mjs
npm run verify
git diff --check
echo "TASK6_LOCAL_VERIFY=PASS"

git add .github/workflows/mobile-inbox-worker.yml tests/worker-contract.test.mjs
git diff --cached --check

git commit -m "feat(cs-01): automate canonical mobile inbox intake"
git push origin work/cs-01

HEAD_SHA="$(git rev-parse HEAD)"
REPO="$(gh repo view --json nameWithOwner -q .nameWithOwner)"
RUN_ID=""

for _ in $(seq 1 60); do
  RUN_ID="$(
    gh api "repos/$REPO/actions/runs?branch=work%2Fcs-01&event=push&per_page=50" \
      --jq ".workflow_runs[] | select(.head_sha == \"$HEAD_SHA\" and .name == \"canonical-ci\") | .id" \
      2>/dev/null | head -n1 || true
  )"
  [ -n "$RUN_ID" ] && break
  sleep 5
done

if [ -z "$RUN_ID" ]; then
  echo "ERROR: canonical-ci run not found for Task 6 commit"
  exit 1
fi

echo "TASK6_CANONICAL_RUN_ID=$RUN_ID"
if ! gh run watch "$RUN_ID" --exit-status; then
  echo "TASK6_CANONICAL_CI=FAIL"
  gh run view "$RUN_ID" --log-failed || true
  exit 1
fi
echo "TASK6_CANONICAL_CI=PASS"

STATUS=""
for _ in $(seq 1 24); do
  STATUS="$(
    gh api "repos/$REPO/commits/$HEAD_SHA/status" \
      --jq '[.statuses[] | select(.context == "canonical-verify")][0].state // ""' \
      2>/dev/null || true
  )"
  [ "$STATUS" = "success" ] && break
  [ "$STATUS" = "failure" ] && break
  sleep 5
done

echo "TASK6_CANONICAL_STATUS=${STATUS:-missing}"
[ "$STATUS" = "success" ] || exit 1

echo "TASK6_RESULT=PASS"
echo "TASK6_LIVE_UAT=DEFERRED_TO_FINAL_CS01_GATE"
echo "BRANCH=$(git branch --show-current)"
echo "COMMIT=$HEAD_SHA"
echo "WORKTREE_CLEAN=$([ -z "$(git status --porcelain)" ] && echo yes || echo no)"
